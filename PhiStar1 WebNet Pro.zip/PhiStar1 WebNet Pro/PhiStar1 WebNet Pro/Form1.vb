﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        WebBrowser1.Navigate("Https://www.google.de/")

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub BeendenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BeendenToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub AppInfoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AppInfoToolStripMenuItem.Click
        MessageBox.Show("Version: 1.0, Programmierer: PhiStar1. Folgt mir gerne auf Insta und abonniert meinen YouTube-Channel. Instagram: phistar1, YouTube: PhiStar1", "App-Info")

    End Sub

    Private Sub LesezeichenHinufügenToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ZurückToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ZurückToolStripMenuItem.Click
        WebBrowser1.GoBack()


    End Sub

    Private Sub VorwärtsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VorwärtsToolStripMenuItem.Click
        WebBrowser1.GoForward()

    End Sub

    Private Sub AktualisierenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AktualisierenToolStripMenuItem.Click
        WebBrowser1.Refresh()

    End Sub

    Private Sub HomepageÖffnenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomepageÖffnenToolStripMenuItem.Click
        WebBrowser1.Stop()


    End Sub

    Private Sub LeereSeiteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LeereSeiteToolStripMenuItem.Click
        WebBrowser1.Navigate("about:blank")
        MessageBox.Show("Du hast eine leere Seite gestartet. Um dies zu beheben,  ◀  drücken oder Homepage öffnen", "Leere Seite")

    End Sub

    Private Sub HomepageStartenersetzenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomepageStartenersetzenToolStripMenuItem.Click
        WebBrowser1.Navigate("https://www.google.de/")

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        WebBrowser1.GoBack()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        WebBrowser1.GoForward()
    End Sub

    Private Sub LeereSeiteneuerTabToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabEntfernenToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        WebBrowser1.Navigate("Https://www.google.de/")
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        WebBrowser1.Stop()
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        WebBrowser1.Navigate(TextBox1.Text)
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem.Click
        WebBrowser1.Navigate(TextBox1.Text)
    End Sub
End Class
