# WebNet-Pro
 Ein einfacher Web-Browser für Windows. Diese App wurde programmiert von PhiStar1. Die App ist Open-Source. Das heißt, sie ist kostenlos, darf verbreitet und modifiziert werden. 
