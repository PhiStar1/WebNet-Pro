﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AppToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BeendenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebseiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZurückToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VorwärtsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AktualisierenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomepageÖffnenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LeereSeiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomepageStartenersetzenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 64)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 18)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(1688, 781)
        Me.WebBrowser1.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AppToolStripMenuItem, Me.WebseiteToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1688, 33)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AppToolStripMenuItem
        '
        Me.AppToolStripMenuItem.BackColor = System.Drawing.SystemColors.Desktop
        Me.AppToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BeendenToolStripMenuItem, Me.AppInfoToolStripMenuItem})
        Me.AppToolStripMenuItem.Name = "AppToolStripMenuItem"
        Me.AppToolStripMenuItem.Size = New System.Drawing.Size(62, 29)
        Me.AppToolStripMenuItem.Text = "App"
        '
        'BeendenToolStripMenuItem
        '
        Me.BeendenToolStripMenuItem.Name = "BeendenToolStripMenuItem"
        Me.BeendenToolStripMenuItem.Size = New System.Drawing.Size(187, 34)
        Me.BeendenToolStripMenuItem.Text = "Beenden"
        '
        'AppInfoToolStripMenuItem
        '
        Me.AppInfoToolStripMenuItem.Name = "AppInfoToolStripMenuItem"
        Me.AppInfoToolStripMenuItem.Size = New System.Drawing.Size(187, 34)
        Me.AppInfoToolStripMenuItem.Text = "App-Info"
        '
        'WebseiteToolStripMenuItem
        '
        Me.WebseiteToolStripMenuItem.BackColor = System.Drawing.SystemColors.Desktop
        Me.WebseiteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ZurückToolStripMenuItem, Me.VorwärtsToolStripMenuItem, Me.AktualisierenToolStripMenuItem, Me.HomepageÖffnenToolStripMenuItem, Me.LeereSeiteToolStripMenuItem, Me.HomepageStartenersetzenToolStripMenuItem, Me.NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem})
        Me.WebseiteToolStripMenuItem.Name = "WebseiteToolStripMenuItem"
        Me.WebseiteToolStripMenuItem.Size = New System.Drawing.Size(100, 29)
        Me.WebseiteToolStripMenuItem.Text = "Webseite"
        '
        'ZurückToolStripMenuItem
        '
        Me.ZurückToolStripMenuItem.Name = "ZurückToolStripMenuItem"
        Me.ZurückToolStripMenuItem.Size = New System.Drawing.Size(621, 34)
        Me.ZurückToolStripMenuItem.Text = "Zurück"
        '
        'VorwärtsToolStripMenuItem
        '
        Me.VorwärtsToolStripMenuItem.Name = "VorwärtsToolStripMenuItem"
        Me.VorwärtsToolStripMenuItem.Size = New System.Drawing.Size(621, 34)
        Me.VorwärtsToolStripMenuItem.Text = "Vorwärts"
        '
        'AktualisierenToolStripMenuItem
        '
        Me.AktualisierenToolStripMenuItem.Name = "AktualisierenToolStripMenuItem"
        Me.AktualisierenToolStripMenuItem.Size = New System.Drawing.Size(621, 34)
        Me.AktualisierenToolStripMenuItem.Text = "Aktualisieren"
        '
        'HomepageÖffnenToolStripMenuItem
        '
        Me.HomepageÖffnenToolStripMenuItem.Name = "HomepageÖffnenToolStripMenuItem"
        Me.HomepageÖffnenToolStripMenuItem.Size = New System.Drawing.Size(621, 34)
        Me.HomepageÖffnenToolStripMenuItem.Text = "Aktualisieren beenden"
        '
        'LeereSeiteToolStripMenuItem
        '
        Me.LeereSeiteToolStripMenuItem.Name = "LeereSeiteToolStripMenuItem"
        Me.LeereSeiteToolStripMenuItem.Size = New System.Drawing.Size(621, 34)
        Me.LeereSeiteToolStripMenuItem.Text = "Leere Seite (ersetzen)"
        '
        'HomepageStartenersetzenToolStripMenuItem
        '
        Me.HomepageStartenersetzenToolStripMenuItem.Name = "HomepageStartenersetzenToolStripMenuItem"
        Me.HomepageStartenersetzenToolStripMenuItem.Size = New System.Drawing.Size(621, 34)
        Me.HomepageStartenersetzenToolStripMenuItem.Text = "Homepage starten (ersetzen)"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 33)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(43, 25)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "◀"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(61, 33)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(43, 25)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "▶"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.ForeColor = System.Drawing.Color.Olive
        Me.Button3.Location = New System.Drawing.Point(110, 33)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(43, 24)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "↩"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.ForeColor = System.Drawing.Color.Red
        Me.Button5.Location = New System.Drawing.Point(159, 33)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(43, 23)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "x"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.ForeColor = System.Drawing.Color.Black
        Me.Button6.Location = New System.Drawing.Point(208, 33)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(43, 23)
        Me.Button6.TabIndex = 8
        Me.Button6.Text = "🏚"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(257, 30)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(664, 26)
        Me.TextBox1.TabIndex = 9
        Me.TextBox1.Text = "Gebe eine URL oder einen Suchbegriff ein"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(927, 29)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(111, 31)
        Me.Button4.TabIndex = 10
        Me.Button4.Text = "Lets Go!"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem
        '
        Me.NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem.Name = "NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem"
        Me.NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem.Size = New System.Drawing.Size(621, 34)
        Me.NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem.Text = "Nach in der Textbox eingegebenen Webseite bzw. Begriff suchen"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1688, 836)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "PhiStar WebNet Pro"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AppToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BeendenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AppInfoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WebseiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ZurückToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VorwärtsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AktualisierenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HomepageÖffnenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LeereSeiteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HomepageStartenersetzenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents NachInDerTextboxEingegebenenWebseiteBzwBegriffSuchenToolStripMenuItem As ToolStripMenuItem
End Class
